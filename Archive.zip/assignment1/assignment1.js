/**
 * WEB222 – Assignment 01
 *
 * I declare that this assignment is my own work in accordance with
 * Seneca Academic Policy. No part of this assignment has been
 * copied manually or electronically from any other source
 * (including web sites) or distributed to other students.
 *
 * Please update the following with your information:
 *
 *      Name: <YOUR_NAME>
 *      Student ID: <YOUR_STUDENT_ID>
 *      Date: <SUBMISSION_DATE>
 *
 * Follow all instructions in README.md
 */

/**
 * Task 1 - format a file path as a Windows or Unix path.
 *
 * `dir` - a String with the name of the directory (e.g., 'documents')
 * `filename` - a String with the name of a file (e.g., 'resume')
 * `ext` - a String with a file extension (e.g., 'txt'), or the empty string
 * if there is no file extension.
 * `windowsDrive` - an optional String, which indicates a Windows Drive,
 * for example 'C:'.  If present, create a Windows path. Otherwise a Unix path.
 */
function formatPath(dir, filename, ext, windowsDrive) {

}

/**
 * Task 2 - Write a Function Expression to convert a temperature in Celsius
 * or Fahrenheit to Kelvin, returning a formatted string (e.g., "288.71 K").
 *
 * `temp` - a Number with a temperature value (e.g., 17)
 * `unit` - a String with a temperature scale unit.  Should be one of:
 * C, c, F, or F.  If no value is given, assume F. If anything else is given,
 * throw an error, "unknown unit". Hint:
 * https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Statements/throw#Description
 */
var tempToKelvin = function(temp, unit) {

};

/**
 * Task 3 - find the smallest number in a list.
 *
 * Allow any number of arguments to be passed to the function.  Allow both
 * String and Number arguments to be passed, but throw an error if any other
 * type is passed to the function (e.g., Boolean, Date, etc.). If the list
 * is empty (nothing passed to the function), return Number.MIN_VALUE, see:
 * https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number/MIN_VALUE
 */
function findSmallest() {

}

/**
 * Task 4 - find all odd numbers in a list.
 *
 * Allow any number of Number arguments to be passed to the function.
 * If a value is passed to the function that is not a Number, ignore it
 * and continue processing the rest. If the list is empty (nothing passed
 * to the function, or all need to be ignored, return `null`).
 *
 * Return a formatted string with all odd numbers in a list, for example:
 *
 * "1, 3, 5"
 */
function oddNumbers() {

}

/**
 * Task 5 - calculate the Harmonized Sales Tax (HST) for a value in cents.
 *
 * Return the value of a purchase with HST (13%) added to the dollars and
 * cents arguments.  Both are expected to be Numbers, and if cents is missing,
 * assume 0.
 *
 * If the cost is exactly 25 cents, apply no HST on the purchase.
 *
 * Throw away any fractional cents, always returning a whole number. Hint:
 * https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Math/floor
 */
function addHST(cents) {

}

/**
 * Task 6 - calculate tax for all purchase items in a sale.
 *
 * Allow any number of arguments to be passed to the function, representing
 * purchase values in an order.  All items will be Strings in the form "3.16"
 * or "1.00" or "0.25"; that is, a possible Dollar value, and a 2 decimal cents
 * value, which might be 00.
 *
 * Make use of the addHST() function you wrote above, and convert all String
 * values to a Number of cents, get the new value with HST added, and keep
 * a running total for all items.  Return a String formatted like so: "$15.67",
 * with the total order value, including tax.
 *
 * If the total value with tax is 0, return it as "$0.00" vs. "$0".
 */
function orderTotalWithTax(...items) {

}

/**
 * Task 7 - make name=value pairs ready for inclusion on a URL's query string
 *
 * A URL can contain optional name=value pairs at the end. See:
 * https://web222.ca/weeks/week01/#urls
 *
 * For example:
 *
 *   https://www.store.com/search?q=dog includes q=dog
 *
 *   https://www.store.com?_encoding=UTF8&node=18521080011 includes
 *   both _encoding=UTF8 and also node=18521080011, separated by &
 *
 * Given a product name (String), quantity (Number), and whether
 * or not this is a gift (Boolean), build and return a query string
 * like this:
 *
 * buildQueryString('shirt', 6);
 *
 * ?p=shirt&q=6
 *
 * Make sure quantity is at least 1 in all cases.  If 0 or a negative number
 * is passed into the function, use 1 instead.
 *
 * If it's a gift, you would do buildQueryString('shirt', 6, true);
 *
 * ?p=shirt&q=6&gift
 *
 * Make sure you properly encode any URL components, since URLs can't
 * contain spaces or certain other characters.  Hint:
 * https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/encodeURIComponent
 */
function buildQueryString(productName, quantity, isGift) {
    
}

/**
 * Do not modify the following code, which exposes your functions to the tests.
 */
module.exports = {
    formatPath,
    tempToKelvin,
    findSmallest,
    oddNumbers,
    addHST,
    orderTotalWithTax,
    buildQueryString
};
