//code below shows version of node
//node - v

/*
//displays hello world
console.log("Hello World");
//shows directory name *two underscores _ _ direname
console.log(__dirname);
//shows file name  *two underscores _ _ filename
console.log(__filename);


//setTimeout()
setTimeout(function(){
    console.log("Hello after 1 second.")
},1000);
console.log("Happy Day"); // happy day displays before prev msg bc prev msg was delayed - asycronis


//setInterval(): execyte a func after a certain delay and continue to 
var count = 1;
var maxCount = 5;
var myCountInterval = setInterval(function(){
    console.log("Hello after "+ (count++) + " seconds(s)");
    checkMaximum();
}, 1000);

//need to call clearInterval() with the timeout object (e.g., myCountInterval)
var checkMaximum = function() {
    if(count> maxCount)
    { clearInterval(myCountInterval);}
}

*/

//read from user's input
//require() readline module

var readline= require('readline');
//createInterface() for input/output
var rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

// rl.question(query, callback)
//displays the query by writing it to the output, waits for the user input to be
//then invokes the callback function passing the provided input as the first

rl.question("enter your name: ", function(answer){
    console.log("hello " + answer);
    //the interface is closed bc it waits for hte data to be received 
    rl.close();
})