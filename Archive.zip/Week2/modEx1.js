//require a user-defined module
var message = require("./modules/message.js");

//execute function writeMessage() so that it is accesible
message.writeMessage("Hello ");
message.readMessage();

//localFunction() was not exported in the user-defined mod
message.localFunction(); //TypeError: message.localFunction
