//
//  ViewController.swift
//  Sep12
//
//  Created by Luca Padula on 2018-09-12.
//  Copyright © 2018 Luca Padula. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    // Local fields
    
    // Outlets
    
    @IBOutlet weak var resultText: UITextView!
    
    @IBOutlet weak var gpaValue: UITextField!
    
    @IBOutlet weak var gpaSlider: UISlider!
    
    @IBOutlet weak var programSelector: UISegmentedControl!
    
    @IBOutlet weak var levelSelector: UISegmentedControl!
    
    // Lifecycle functions

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // Actions

    @IBAction func gpaChanged(_ sender: UISlider) {
        print("GPA Changed")
    }
    
    @IBAction func programChanged(_ sender: UISegmentedControl) {
        print("Program Changed")
        resultText.text = "Program Changed"
    }
    
    @IBAction func levelChanged(_ sender: UISegmentedControl) {
        print("Level Changed")
    }
    
}
