//
//  ViewController.swift
//  Lab9
//
//  Created by Anh Tran on 2019-04-02.
//  Copyright © 2019 Anh Tran. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

