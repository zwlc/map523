//
//  ViewController.swift
//  lab7
//
//  Created by Shichao Wang on 2019-03-13.
//  Copyright © 2019 dev. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class ViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {
    @IBOutlet weak var uiLatitude: UILabel!
    @IBOutlet weak var uiLongitude: UILabel!
    @IBOutlet weak var uiAltitude: UILabel!
    @IBOutlet weak var uiCourse: UILabel!
    @IBOutlet weak var uiSpeed: UILabel!
    @IBOutlet weak var uiNearestAddress: UILabel!
    var locationManager = CLLocationManager()
    var latitude : CLLocationDegrees?;
    var longitude : CLLocationDegrees?;
    var altitude : CLLocationDistance?;
    var course : CLLocationDirection?;
    var speed : CLLocationSpeed?;
    var nearestaddress = "";
    var t1 = Timer();
    var t2 = Timer();
    override func viewDidLoad() {
        super.viewDidLoad()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        updateData();
        updateUI();
        t1 = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(updateData), userInfo: nil, repeats: true)
        t2 = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(updateUI), userInfo: nil, repeats: true)
    }
    
    @objc func updateData(){
        let location = self.locationManager.location
        latitude = location?.coordinate.latitude;
        longitude = location?.coordinate.longitude;
        altitude = location?.altitude;
        course = location?.course;
        speed = location?.speed;
        
        //address
        if latitude != nil && longitude != nil{
            let loc = CLLocation(latitude: self.latitude!, longitude: (longitude)!);
            let geo = CLGeocoder().reverseGeocodeLocation(loc) { (placemark, error) in
                if error != nil{
                    print("error");
                }else{
                    let place = placemark! as [CLPlacemark];
                    if place.count > 0{
                        let place = placemark![0];
                        var address = "";
                        if place.thoroughfare != nil{
                            address = address + place.thoroughfare! + ",";
                        }
                        if place.subThoroughfare != nil{
                            address = address + place.subThoroughfare! + " ";
                        }
                        if place.locality != nil{
                            address = address + place.locality! + "\n";
                        }
                        
                        if place.postalCode != nil {
                            address = address + place.postalCode! + "\n"
                        }
                        
                        if place.country != nil{
                            address = address + place.country!
                        }
                        print(address);
                        self.nearestaddress = address;
                    }
                }
            }
        }
    }
    
    @objc func updateUI(){
        uiLatitude.text = "\(latitude!)";
        uiLongitude.text = "\(longitude!)";
        uiAltitude.text = "\(altitude!)";
        uiCourse.text = "\(course!)"
        uiSpeed.text = "\(speed!)"
        uiNearestAddress.text = "\(nearestaddress)"
        uiNearestAddress.sizeToFit();
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation])
    {
        print("Hello")
        print(locations)
        
        let userLocation: CLLocation = locations[0]
        
        let latitude = userLocation.coordinate.latitude
        let longitude = userLocation.coordinate.longitude
        
        let longDelta = 0.05
        let latDelta = 0.05
        
        let span = MKCoordinateSpan(latitudeDelta: latDelta, longitudeDelta: longDelta)
        let location = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
        let region = MKCoordinateRegion(center: location, span: span)
    }
    
}

